export class OpticalConnection {}
