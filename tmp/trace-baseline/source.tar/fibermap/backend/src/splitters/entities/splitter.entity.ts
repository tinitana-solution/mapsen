export class Splitter {}
