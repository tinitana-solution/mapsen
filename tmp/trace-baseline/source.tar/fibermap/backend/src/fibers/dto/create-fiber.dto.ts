export class CreateFiberDto {}
