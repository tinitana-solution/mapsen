export class Inventory {}
