export class CreateZoneDto {}
