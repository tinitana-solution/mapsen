export class CreateTubeDto {}
